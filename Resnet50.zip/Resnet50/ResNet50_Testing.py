#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 17 17:51:52 2021

@author: arifcse21
"""
import tensorflow as tf
import cv2
import numpy as np

class_names=['Bacterial_Spot',
 'Early_Blight',
 'Healthy',
 'Late_Blight',
 'Leaf_Mold',
 'Mosaic_Virus',
 'Septoria_Leaf_Spot',
 'Spider_Mites_Spot',
 'Target_Spot',
 'Yellow_Leaf_Curl_Virus']

def prepare(filepath):
    IMG_SIZE=224
    img_array = cv2.imread(filepath)
    new_array=cv2.resize(img_array, (IMG_SIZE,IMG_SIZE))
    return new_array.reshape(-1, IMG_SIZE, IMG_SIZE, 3)

model = tf.keras.models.load_model('resnet50-weights-improvement.h5')
model.summary()


#prediction = model.predict([prepare('/mnt/Documents/Project⁄Thesis/InceptionV3/Splitted_Dataset_54/test/Mosaic_Virus/1b9dc07a-40ab-45bc-a873-1ad4212e35a3___PSU_CG 2289_final_masked.jpg')])
#print(prediction)
#prediction = class_names[int(np.argmax(prediction))]
#print(prediction)



